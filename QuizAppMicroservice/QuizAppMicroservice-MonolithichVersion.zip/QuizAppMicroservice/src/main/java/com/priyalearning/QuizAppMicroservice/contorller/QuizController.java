package com.priyalearning.QuizAppMicroservice.contorller;

import com.priyalearning.QuizAppMicroservice.model.Question;
import com.priyalearning.QuizAppMicroservice.model.QuestionWrapper;
import com.priyalearning.QuizAppMicroservice.model.Responses;
import com.priyalearning.QuizAppMicroservice.service.QuizService;
import net.bytebuddy.implementation.bind.MethodDelegationBinder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.xml.ws.Response;
import java.util.List;

@RestController
@RequestMapping("Quiz")
public class QuizController {
@Autowired
    QuizService quizservice;

/*
Creating Quiz - POST
URL used for testing - http://localhost:8080/Quiz/create?category=Java&numQ=5&title=JQuiz
*/
    @RequestMapping("create")  //--> will use RequestParama
    public ResponseEntity<String> createQuiz(@RequestParam String category,@RequestParam int numQ, @RequestParam String title){
        System.out.println("Entering into CreateQuiz"+category+numQ+title);

          return  quizservice.createQuiz(category, numQ, title);
        }



   /*Fetching Quiz - GET
        http://localhost:8080/Quiz/get/2*/
@GetMapping("get/{id}")   //--> will use Path Varibale for URL variables
    public ResponseEntity<List<QuestionWrapper>> getQuizQuestions(@PathVariable Integer id){
    return quizservice.getQuizQuestion(id);
}

/*Caculating the Quiz Score by submitting responsefrom Postman
URL : Post - http://localhost:8080/Quiz/submit/2
Response Body - JSON:
[
    {
        "id": 1,
        "response": "public"
    },
    {
        "id": 3,
        "response": "private"
    },
    {
        "id": 5,
        "response": "protected"
    },
    {
        "id": 10,
        "response": "three"
    },
    {
        "id": 4,
        "response": "public"
    }
]


 */
@PostMapping("submit/{id}")
    public ResponseEntity<Integer> submitQuiz(@PathVariable Integer id, @RequestBody List<Responses> responses){
    return quizservice.calculateResult(id,responses);
    }


}


