package com.priyalearning.QuizAppMicroservice.service;

import com.priyalearning.QuizAppMicroservice.dao.QuestionDao;
import com.priyalearning.QuizAppMicroservice.dao.QuizDao;
import com.priyalearning.QuizAppMicroservice.model.Question;
import com.priyalearning.QuizAppMicroservice.model.QuestionWrapper;
import com.priyalearning.QuizAppMicroservice.model.Quiz;
import com.priyalearning.QuizAppMicroservice.model.Responses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class QuizService {
    @Autowired
    QuizDao quizDao;
    @Autowired
    QuestionDao questionDao;


    public ResponseEntity<String> createQuiz(String category, int numQ, String title) {
        Quiz quiz=new Quiz();
        quiz.setTitle(title);
        System.out.println("Entering into CreateQuiz1"+category+numQ);
        List<Question> questions = questionDao.findRandomQuestionsByCategory(category,numQ);
        System.out.println("Entering into CreateQuiz2"+questions);
        quiz.setQuestions(questions);
        System.out.println("Entering into CreateQuiz3"+quiz );
        quizDao.save(quiz);
        return new ResponseEntity<>("Success", HttpStatus.CREATED);
    }

    public ResponseEntity<List<QuestionWrapper>> getQuizQuestion(Integer id) {
      Optional<Quiz> quiz =  quizDao.findById(id); //The data might have objs or may be null, so, it is optional
        System.out.println("List of Quiz for ID 1 "+quiz);
        //Converting Questions to Question Wrapper
        List<Question> questionsFromDB = quiz.get().getQuestions(); //.get() is used as it is Optional
        List<QuestionWrapper> questionsForUser= new ArrayList<>();
        for(Question q:questionsFromDB){
            QuestionWrapper qw = new QuestionWrapper(q.getId(),q.getQuestion_title(),q.getOption1(),q.getOption2(),q.getOption3());
            questionsForUser.add(qw);
        }
        return  new ResponseEntity<>(questionsForUser,HttpStatus.OK);
    }

    public ResponseEntity<Integer> calculateResult(Integer id, List<Responses> responses) {
        Optional<Quiz> quiz =  quizDao.findById(id); //The data might have objs or may be null, so, it is optional
        List<Question> questions = quiz.get().getQuestions(); //.get() is used as it is Optional
    int score=0;
    int i=0;
    for(Responses response: responses){
        if(response.getResponse().equals(questions.get(i).getRight_ans()))
            System.out.println("I = "+i+"===>"+response.getResponse()+"+++++quest(i)"+questions.get(i)+"======="+questions.get(i).getRight_ans()+"\n");
            score++;
        i++;
    }
        return new ResponseEntity<>(score,HttpStatus.OK);
    }
}
