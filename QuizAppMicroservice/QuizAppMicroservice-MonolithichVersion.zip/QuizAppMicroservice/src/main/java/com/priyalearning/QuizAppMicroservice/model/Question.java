package com.priyalearning.QuizAppMicroservice.model;

import lombok.Data;

import javax.persistence.*;

@Data  //Since we are sing Lombok, no need of setters and getters, else need to create like other pojo classes
@Entity
public class Question {
    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", columnDefinition = "serial")
    @GeneratedValue(strategy = GenerationType.IDENTITY, generator="seq_name_generated_in_db")
    @SequenceGenerator(name="seq_name_generated_in_db", sequenceName="seq_name_generated_in_db", initialValue = 10 , allocationSize=1)
    private Integer id;
    private String category;
    private String difficultylevel;
    private String option1;
    private String option2;
    private String option3;
    private String question_title;
    private String right_ans;

}
