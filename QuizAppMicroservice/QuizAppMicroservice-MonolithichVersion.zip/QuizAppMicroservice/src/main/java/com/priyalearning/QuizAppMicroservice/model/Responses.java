package com.priyalearning.QuizAppMicroservice.model;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor //Lombok will provide parameterized constructor
public class Responses {
    private Integer id;
    private String response;

}
