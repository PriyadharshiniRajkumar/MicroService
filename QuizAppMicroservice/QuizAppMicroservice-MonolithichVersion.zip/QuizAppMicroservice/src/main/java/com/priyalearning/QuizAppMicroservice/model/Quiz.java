package com.priyalearning.QuizAppMicroservice.model;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity //used to create table
@Data   //Lombok to create getter ad setter
public class Quiz {
    @Id //Used to mention as Primary Key
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String title;

    @ManyToMany //Many Quiz with multiple Questions
    private List<Question> questions;

}

