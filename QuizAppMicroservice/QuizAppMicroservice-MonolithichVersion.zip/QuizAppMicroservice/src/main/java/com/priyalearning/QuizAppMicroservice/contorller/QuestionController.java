package com.priyalearning.QuizAppMicroservice.contorller;



import com.priyalearning.QuizAppMicroservice.model.Question;
import com.priyalearning.QuizAppMicroservice.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("question")
public class QuestionController{

@Autowired
    QuestionService questionService;
    @GetMapping("allQuestions")
    //ResponseEntity is a class, which will send response along with its Status code.
    public ResponseEntity<List<Question>> getAllQuestions(){

        return questionService.getAllQuestions();
    }


    @GetMapping("category/{category}")
    public ResponseEntity<List<Question>> getQuestionsbyCategory(@PathVariable String category){

        return questionService.getQuestionsbyCategory(category);
    }

    @PostMapping("add")
    public ResponseEntity<String> addQuestions(@RequestBody Question question){

        return  questionService.addQuestions(question);
    }
}
