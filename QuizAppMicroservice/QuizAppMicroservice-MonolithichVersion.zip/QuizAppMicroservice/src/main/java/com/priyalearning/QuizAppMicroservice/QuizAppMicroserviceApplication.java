package com.priyalearning.QuizAppMicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuizAppMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuizAppMicroserviceApplication.class, args);
	}

}
