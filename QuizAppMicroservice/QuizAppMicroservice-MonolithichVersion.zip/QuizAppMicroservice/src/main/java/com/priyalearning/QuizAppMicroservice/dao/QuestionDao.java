package com.priyalearning.QuizAppMicroservice.dao;

import com.priyalearning.QuizAppMicroservice.model.Question;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QuestionDao extends JpaRepository<Question,Integer> {

    //Since we are using JPA, no need to follow 7 steps to JDBC connectivity
    // just extends to JPARepo and mention Table class and type of Primary key

    List<Question> findByCategory(String category);

    @Query(nativeQuery = true,value="SELECT * FROM question q Where q.category=:category ORDER BY RANDOM() LIMIT :numQ")
    List<Question> findRandomQuestionsByCategory(String category, int numQ);

}
